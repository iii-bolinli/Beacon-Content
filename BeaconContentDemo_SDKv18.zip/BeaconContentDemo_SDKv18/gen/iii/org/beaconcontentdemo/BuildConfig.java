/** Automatically generated file. DO NOT MODIFY */
package iii.org.beaconcontentdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}