package iii.org.tw.pushmessage;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.ResultReceiver;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;

import java.util.ArrayList;

import tw.org.iii.beaconcontentsdk.BeaconContentService;
import tw.org.iii.beaconcontentsdk.json.get_beacon_list.AppBeacon;

public class BeaconListActivity extends AppCompatActivity {

    ServiceResultReceiver scanWithKeyReceiver;
    String server_ip = "";
    String app_key = "";

    AppBeacon AppBeacon;

    ListView listView;
    Button start_btn, stop_btn, setting_btn;
    RecordListAdapter adapter;

    ArrayList<nearBeacon> nearBeacon_list = new ArrayList<>();
    ArrayList<String> listed_beacons = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beacon_list);

        setting_btn = (Button) findViewById(R.id.setting_btn);
        listView = (ListView) findViewById(R.id.listView);
        start_btn = (Button) findViewById(R.id.start_btn);
        stop_btn = (Button) findViewById(R.id.stop_btn);

        setListener();
    }

    @Override
    public void onResume() {
        super.onResume();
        SharedPreferences appData = getApplication().getSharedPreferences("PushMessage",0);
        server_ip = appData.getString("server_ip", "iiibeacon.net"); // 52.69.184.56  為測試機
        app_key = appData.getString("app_key", "221534b65b64545abecb96339f904bb2aed8e9aa");
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    public void setListener(){
        setting_btn.setOnClickListener(setting_btn_Click);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
         @Override
         public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
             Intent intent = new Intent();
             intent.setClass(BeaconListActivity.this, PushMessageContent.class);
             intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
             intent.putExtra("beacon_id", nearBeacon_list.get(position).getBeacon_id());
             startActivity(intent);
         }
        });

        start_btn.setOnClickListener(start_btn_Click);
        stop_btn.setOnClickListener(stop_btn_Click);
    }

    private Button.OnClickListener setting_btn_Click = new Button.OnClickListener() {
        @Override
        public void onClick(View v) {
            stop_scanning();
            Intent intent = new Intent();
            intent.setClass(BeaconListActivity.this, SettingActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
        }
    };

    private Button.OnClickListener start_btn_Click = new Button.OnClickListener() {
        @Override
        public void onClick(View v) {
            scanWithKeyReceiver = new ServiceResultReceiver(null);

            Intent serviceIntent = new Intent(BeaconListActivity.this, BeaconContentService.class);

            serviceIntent.putExtra("server_ip", server_ip);
            serviceIntent.putExtra("app_key", app_key);

            serviceIntent.putExtra("detect_timer", 120*1000);
            serviceIntent.putExtra("receiver", scanWithKeyReceiver);

            startService(serviceIntent);
        }
    };

    private Button.OnClickListener stop_btn_Click = new Button.OnClickListener() {
        @Override
        public void onClick(View v) {
            stop_scanning();
        }
    };

    public void stop_scanning(){
        Intent intent = new Intent(BeaconListActivity.this, BeaconContentService.class);
        stopService(intent);
        nearBeacon_list.clear();
        listed_beacons.clear();
        adapter = new RecordListAdapter(BeaconListActivity.this, nearBeacon_list);
        listView.setAdapter(adapter);
    }

    @SuppressLint("ParcelCreator")
    class ServiceResultReceiver extends ResultReceiver {
        public ServiceResultReceiver(Handler handler) {
            super(handler);
        }

        @Override
        protected void onReceiveResult(int resultCode, final Bundle resultData) {
            if (resultCode == 300){
                String beaconJson = resultData.getString("beaconJson");
                Gson gson = new Gson();
                AppBeacon = gson.fromJson(beaconJson, AppBeacon.class);
                final String beacon_id = AppBeacon.getBeaconID();
                String target_beacon = AppBeacon.getUuid();
                final String beacon_distance = String.format("%.2f", resultData.getDouble("distance"));

                final nearBeacon returned_beacon = new nearBeacon(beacon_id, target_beacon, beacon_distance);
                if (!listed_beacons.contains(beacon_id)){
                    listed_beacons.add(beacon_id);
                    runOnUiThread(new Runnable() {
                          @Override
                          public void run() {
                              nearBeacon_list.add(returned_beacon);
                              adapter = new RecordListAdapter(BeaconListActivity.this, nearBeacon_list);
                              listView.setAdapter(adapter);
                          }
                    });
                }else{
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            int id = listed_beacons.indexOf(beacon_id);
                            View v = listView.getChildAt(id -
                                    listView.getFirstVisiblePosition());
                            if(v != null){
                                TextView distance = (TextView) v.findViewById(R.id.beacon_distance);
                                String distance_text = "distance(m):"+beacon_distance;
                                distance.setText(distance_text);
                            }
                        }
                    });
                }
            }
        }
    }

    public class nearBeacon {
        private String beacon_id;
        private String uuid;
        private String distance;
        public nearBeacon(String position_id, String name, String distance) {
            this.beacon_id = position_id;
            this.uuid = name;
            this.distance = distance;
        }
        public String getBeacon_id(){
            return beacon_id;
        }
        public void setBeacon_id(String beacon_id){
            this.beacon_id = beacon_id;
        }
        public String getUuid(){
            return uuid;
        }
        public void setUuid(String uuid){
            this.uuid = uuid;
        }
        public String getDistance(){
            return distance;
        }
        public void setDistance(String distance){
            this.distance = distance;
        }
    }

    private static class RecordListAdapter extends ArrayAdapter<nearBeacon> {
        // XML Layout, 通常自定Layou就會寫死在類別裡，不再透過引數傳入以免產生誤用
        private static final int mResourceId = R.layout.list_view_item;  //自定的layout
        private LayoutInflater mInflater;
        private ArrayList<nearBeacon> data;

        public RecordListAdapter(Context context, ArrayList<nearBeacon> objects) {
            super(context, mResourceId, objects);
            mInflater = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);
            data = objects;
        }

        public ArrayList<nearBeacon> getData() {
            return data;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = mInflater.inflate(mResourceId, parent, false);
            }
            TextView beacon_id, beacon_uuid, beacon_distance;

            beacon_id = (TextView) convertView.findViewById(R.id.beacon_id);
            String id_text = "ID:"+(CharSequence) getItem(position).getBeacon_id();
            beacon_id.setText(id_text);

            beacon_uuid = (TextView) convertView.findViewById(R.id.beacon_uuid);
            String uuid_text = "UUID:"+(CharSequence) getItem(position).getUuid();
            beacon_uuid.setText(uuid_text);

            beacon_distance = (TextView) convertView.findViewById(R.id.beacon_distance);
            String distance_text = "distance(m):"+(CharSequence) getItem(position).getDistance();
            beacon_distance.setText(distance_text);

            return convertView;
        }
    }
}
