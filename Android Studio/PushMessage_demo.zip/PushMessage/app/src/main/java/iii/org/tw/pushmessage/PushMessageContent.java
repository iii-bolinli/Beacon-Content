package iii.org.tw.pushmessage;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.util.List;

import tw.org.iii.beaconcontentsdk.BeaconContent;
import tw.org.iii.beaconcontentsdk.json.push_message.Coupons;
import tw.org.iii.beaconcontentsdk.json.push_message.Push_message;
import tw.org.iii.beaconcontentsdk.json.push_message.Result_content;

public class PushMessageContent extends AppCompatActivity {

    Push_message push_message;
    Result_content Result_content;
    List<Coupons> Coupons;

    String server_ip = "";
    String app_key = "";

    Button btn_back;
    ImageView coupon_image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_push_message_content);

        SharedPreferences appData = getApplication().getSharedPreferences("PushMessage",0);
        server_ip = appData.getString("server_ip", "iiibeacon.net");
        app_key = appData.getString("app_key", "221534b65b64545abecb96339f904bb2aed8e9aa");

        Intent intent = getIntent();
        String beacon_id = intent.getStringExtra("beacon_id");

        BeaconContent BC = new BeaconContent(server_ip);

        push_message = BC.beaconContentByBeaconID(beacon_id, app_key);

        Result_content = push_message.getResult_content();
        Coupons = Result_content.getCoupons();
        Log.e("url", Coupons.get(0).getPhotoUrl());
        findViews();
        setListeners();
    }
    public void findViews(){
        coupon_image = (ImageView) findViewById(R.id.coupon_image);
        btn_back = (Button) findViewById(R.id.btn_back);

        Picasso.with(PushMessageContent.this)
                .load(Coupons.get(0).getPhotoUrl())
                .placeholder(R.drawable.progress_animation)
                .into(coupon_image);
    }

    public void setListeners(){
        btn_back.setOnClickListener(back_Click);
    }

    private Button.OnClickListener back_Click = new Button.OnClickListener() {
        @Override
        public void onClick(View v) {
            finish();
        }
    };
}
