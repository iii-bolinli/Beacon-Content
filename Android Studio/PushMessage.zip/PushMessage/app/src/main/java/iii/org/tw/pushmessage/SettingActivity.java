package iii.org.tw.pushmessage;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SettingActivity extends AppCompatActivity {

    EditText server_ip, app_key;
    Button setting_confirm;

    SharedPreferences appData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        appData = getApplication().getSharedPreferences("PushMessage",0);

        server_ip = (EditText) findViewById(R.id.server_ip);
        app_key = (EditText) findViewById(R.id.app_key);
        setting_confirm = (Button) findViewById(R.id.setting_confirm);

        server_ip.setText(appData.getString("server_ip", "iiibeacon.net"));
        app_key.setText(appData.getString("app_key", "36101de29093fad767e5b1a751036bccf37f3580"));

        setting_confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = appData.edit();
                editor.putString("server_ip", server_ip.getText().toString());
                editor.putString("app_key", app_key.getText().toString());
                editor.commit();

                Intent intent = new Intent();
                intent.setClass(SettingActivity.this, BeaconListActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
            }
        });
    }
}
