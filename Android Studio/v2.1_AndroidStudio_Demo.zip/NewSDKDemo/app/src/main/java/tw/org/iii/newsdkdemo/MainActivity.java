package tw.org.iii.newsdkdemo;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.google.gson.Gson;

import java.util.List;

import tw.org.iii.beaconcontentsdk.BeaconContent;
import tw.org.iii.beaconcontentsdk.BeaconContentService;
import tw.org.iii.beaconcontentsdk.json.get_beacon_list.ListBeacons;
import tw.org.iii.beaconcontentsdk.json.push_message.Coupons;
import tw.org.iii.beaconcontentsdk.json.push_message.Products;
import tw.org.iii.beaconcontentsdk.json.push_message.Push_message;
import tw.org.iii.beaconcontentsdk.json.push_message.Result_content;

public class MainActivity extends AppCompatActivity {

    String TAG = "MainActivity";
    // Step 1. create ResultReceiver to receive result from the scan
    ServiceResultReceiver scanWithKeyReceiver;

    int count = 0;
    String server_ip = "target-server";
    String app_key = "your-app-key";

    Push_message push_message;
    ListBeacons ListBeacons;
    Result_content Result_content;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public void onResume() {
        super.onResume();
        // Step 2. start scan service and send receiver, requested data to it.
        scanWithKeyReceiver = new ServiceResultReceiver(null);
        Intent serviceIntent = new Intent(MainActivity.this, BeaconContentService.class);
        serviceIntent.putExtra("server_ip", server_ip); // must provide
        serviceIntent.putExtra("app_key", app_key); // must provide
        // detect_timer is not necessary, default will update every 3 minutes.
        serviceIntent.putExtra("detect_timer", 120*1000); // in milliseconds, set to 2 minutes in this demo.
        serviceIntent.putExtra("receiver", scanWithKeyReceiver); // must provide

        startService(serviceIntent);
    }

    // Step 3. get scan result, in this case, a beacon list requested by APP key
    @SuppressLint("ParcelCreator")
    class ServiceResultReceiver extends ResultReceiver {
        public ServiceResultReceiver(Handler handler) {
            super(handler);
        }

        @Override
        protected void onReceiveResult(int resultCode, final Bundle resultData) {

            // result code 300: got beacon in the list.
            if (resultCode == 300) {
                String beaconJson = resultData.getString("beaconJson");
                Log.e(TAG, beaconJson);
                Gson gson = new Gson();
                ListBeacons = gson.fromJson(beaconJson, ListBeacons.class);
                String target_beacon = ListBeacons.getUuid();
                Log.e(TAG, target_beacon);

                if (target_beacon.equals("target-beacon")){
                    BeaconContent BC = new BeaconContent(server_ip);

                    push_message = BC.beaconContent(target_beacon, app_key);
//		輸出 Push_message 資料
                    System.out.println("Push_message:");
                    System.out.println("Resource:\""+ push_message.getResource()+"\"");
                    System.out.println("Method:\""+ push_message.getMethod()+"\"");
                    System.out.println("Result:\""+ push_message.getResult()+"\"");
                    System.out.println("Error Msg:\""+ push_message.getError_msg()+"\"");
                    System.out.println("Result Content:");
                    System.out.println("Coupons:");
                    Result_content = push_message.getResult_content();
                    List<Coupons> Coupons = Result_content.getCoupons();
                    for(int i = 0; i<Coupons.size() ;i++){
                        System.out.println("sellerName:"
                                +Coupons.get(i).getSellerName());
                        System.out.println("sellerDescription:"
                                +Coupons.get(i).getSellerDescription());
                        System.out.println("couponBriefDescription:"
                                +Coupons.get(i).getCouponBriefDescription());
                        System.out.println("couponDetailDescription:"
                                +Coupons.get(i).getCouponDetailDescription());
                        System.out.println("others:"
                                +Coupons.get(i).getOthers());
                        System.out.println("quantity:"
                                +Coupons.get(i).getQuantity());
                        System.out.println("surplus:"
                                +Coupons.get(i).getSurplus());
                        System.out.println("photoUrl:"
                                +Coupons.get(i).getPhotoUrl());
                        System.out.println("validStartDate:"
                                +Coupons.get(i).getValidStartDate());
                        System.out.println("validEndDate:"
                                +Coupons.get(i).getValidEndDate());
                    }
                    System.out.println("==============================================");
                    System.out.println("Products:");
                    List<Products> Products = Result_content.getProducts();
                    for(int i = 0; i<Products.size() ;i++){
                        System.out.println("sellerName:"
                                +Products.get(i).getSellerName());
                        System.out.println("sellerDescription:"
                                +Products.get(i).getSellerDescription());
                        System.out.println("productBriefDescription:"
                                +Products.get(i).getProductBriefDescription());
                        System.out.println("productDetailDescription:"
                                +Products.get(i).getProductDetailDescription());
                        System.out.println("others:"
                                +Products.get(i).getOthers());
                        System.out.println("originPrice:"
                                +Products.get(i).getOriginPrice());
                        System.out.println("sellPrice:"
                                +Products.get(i).getSellPrice());
                        System.out.println("discount:"
                                +Products.get(i).getDiscount());
                        System.out.println("quantity:"
                                +Products.get(i).getQuantity());
                        System.out.println("surplus:"
                                +Products.get(i).getSurplus());
                        System.out.println("photoUrl:"
                                +Products.get(i).getPhotoUrl());
                        System.out.println("validStartDate:"
                                +Products.get(i).getValidStartDate());
                        System.out.println("validEndDate:"
                                +Products.get(i).getValidEndDate());
                    }
//		輸出 Push_message 資料 ---- 結束
                }

                count++;
            }
            if (count == 4) {
                // stop it
                Intent intent = new Intent(MainActivity.this, BeaconContentService.class);
                stopService(intent);
            }
        }
    }

}
