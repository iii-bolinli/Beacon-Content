/** Automatically generated file. DO NOT MODIFY */
package iii.org.tw.newsdkdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}